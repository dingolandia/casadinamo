export const settingsMock = {
  data: {
    id: 1,
    avisos:
      'SEG. A SEX. 8:00 AS 18:00 - QUA. 8:00 AS 17:00 (11) 3207-3000 • (11) 3207-2668 • (11) 3207-2679',
    bannerTexto:
      'A CASA D&Iacute;NAMO &Eacute; CONFIAN&Ccedil;A#AGILIDADE E RESPEITO PELO CLIENTE#MAIS DE 50 ANOS DE DEDICA&Ccedil;&Atilde;O, TRANSPAR&Ecirc;NCIA E RESPONSABILIDADE',
    textoRodape:
      'Casa Dínamo - Rua: Piratininga, 1076 - Brás, São Paulo - SP, 03042-000 - Tel: (11) 3207-2668',
    createdAt: '2023-10-16T04:46:14.666Z',
    updatedAt: '2023-10-16T04:46:14.666Z',
    locale: 'pt-BR',
  },
  meta: {},
};
