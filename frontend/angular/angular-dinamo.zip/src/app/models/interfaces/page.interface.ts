export interface Icontent {
  id: number;
  titulo: string;
  locale: string;
  conteudo: string;
}
