export interface Isettings{
  id: number;
  avisos: string;
  bannerTexto: string;
  textoRodape: string;
  createdAt: string;
  updatedAt: string;
  locale: string;
}
