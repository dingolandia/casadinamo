import { Component } from '@angular/core';

@Component({
  selector: 'app-modal-user-login',
  templateUrl: './modal-user-login.component.html',
  styleUrls: ['./modal-user-login.component.scss']
})
export class ModalUserLoginComponent {}
