import { Component } from '@angular/core';

@Component({
  selector: 'app-red-bar',
  templateUrl: './red-bar.component.html',
  styleUrls: ['./red-bar.component.scss']
})
export class RedBarComponent {}
